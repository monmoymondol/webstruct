import React, { useState } from 'react';
import { Server, Database, Activity, Shield, Globe, Code, BarChart3, AlertCircle, CheckCircle, Clock } from 'lucide-react';

const BackendDetails = ({ data }) => {
  const [selectedServer, setSelectedServer] = useState(null);
  const [selectedAPI, setSelectedAPI] = useState(null);

  const getStatusColor = (status) => {
    switch (status) {
      case 'healthy': return 'text-green-400 bg-green-500/20';
      case 'warning': return 'text-yellow-400 bg-yellow-500/20';
      case 'critical': return 'text-red-400 bg-red-500/20';
      default: return 'text-gray-400 bg-gray-500/20';
    }
  };

  const getLoadColor = (load) => {
    if (load > 80) return 'bg-red-500';
    if (load > 60) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  return (
    <div className="space-y-6">
      {/* Architecture Overview */}
      <div className="bg-black/30 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20">
        <h3 className="text-xl font-bold text-white mb-6 flex items-center">
          <Server className="h-5 w-5 mr-2 text-purple-400" />
          Backend Architecture
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-4 bg-white/5 rounded-xl">
            <div className="flex items-center space-x-2 mb-3">
              <Globe className="h-5 w-5 text-blue-400" />
              <span className="text-white font-semibold">Architecture Pattern</span>
            </div>
            <div className="text-2xl font-bold text-blue-400 mb-1">{data.backend.architecture}</div>
            <div className="text-sm text-blue-300">Distributed system with service mesh</div>
          </div>
          
          <div className="p-4 bg-white/5 rounded-xl">
            <div className="flex items-center space-x-2 mb-3">
              <Activity className="h-5 w-5 text-green-400" />
              <span className="text-white font-semibold">Uptime</span>
            </div>
            <div className="text-2xl font-bold text-green-400 mb-1">{data.backend.monitoring.uptime}%</div>
            <div className="text-sm text-green-300">Last 30 days</div>
          </div>
          
          <div className="p-4 bg-white/5 rounded-xl">
            <div className="flex items-center space-x-2 mb-3">
              <BarChart3 className="h-5 w-5 text-purple-400" />
              <span className="text-white font-semibold">Throughput</span>
            </div>
            <div className="text-2xl font-bold text-purple-400 mb-1">{data.backend.monitoring.throughput}</div>
            <div className="text-sm text-purple-300">Daily requests</div>
          </div>
        </div>
      </div>

      {/* Server Infrastructure */}
      <div className="bg-black/30 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20">
        <h3 className="text-xl font-bold text-white mb-6 flex items-center">
          <Server className="h-5 w-5 mr-2 text-purple-400" />
          Server Infrastructure
        </h3>
        
        <div className="mb-4 p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
          <div className="flex items-center space-x-2 text-blue-400 mb-2">
            <Shield className="h-4 w-4" />
            <span className="font-semibold">Load Balancer</span>
          </div>
          <div className="text-white">{data.backend.loadBalancer}</div>
          <div className="text-sm text-blue-300 mt-1">Distributing traffic across {data.backend.servers.length} servers</div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {data.backend.servers.map((server, index) => (
            <div 
              key={index} 
              className={`p-4 bg-white/5 rounded-xl border cursor-pointer transition-all duration-200 hover:bg-white/10 ${
                selectedServer === index ? 'border-purple-500 bg-purple-500/10' : 'border-gray-500/20'
              }`}
              onClick={() => setSelectedServer(selectedServer === index ? null : index)}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${server.status === 'healthy' ? 'bg-green-400' : 'bg-red-400'} animate-pulse`}></div>
                  <span className="text-white font-medium">Server {index + 1}</span>
                </div>
                <span className={`text-xs px-2 py-1 rounded ${getStatusColor(server.status)}`}>
                  {server.status}
                </span>
              </div>
              
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-purple-300">IP:</span>
                  <span className="text-white font-mono">{server.ip}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-300">Location:</span>
                  <span className="text-white">{server.location}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-300">Response:</span>
                  <span className="text-cyan-400">{server.responseTime}ms</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-purple-300">Load:</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-16 h-2 bg-gray-600 rounded-full overflow-hidden">
                      <div 
                        className={`h-full ${getLoadColor(server.load)} transition-all duration-300`}
                        style={{ width: `${server.load}%` }}
                      ></div>
                    </div>
                    <span className="text-white text-xs">{server.load}%</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Database Systems */}
      <div className="bg-black/30 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20">
        <h3 className="text-xl font-bold text-white mb-6 flex items-center">
          <Database className="h-5 w-5 mr-2 text-purple-400" />
          Database Systems
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {data.backend.databases.map((db, index) => (
            <div key={index} className="p-4 bg-white/5 rounded-xl border border-gray-500/20">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <Database className="h-5 w-5 text-green-400" />
                  <span className="text-white font-semibold">{db.type}</span>
                </div>
                <span className="text-sm text-green-400 bg-green-500/20 px-2 py-1 rounded">
                  v{db.version}
                </span>
              </div>
              
              <div className="space-y-3">
                {db.replicas && (
                  <div className="flex justify-between">
                    <span className="text-purple-300">Replicas:</span>
                    <span className="text-white">{db.replicas}</span>
                  </div>
                )}
                
                {db.connectionPool && (
                  <div className="flex justify-between">
                    <span className="text-purple-300">Connection Pool:</span>
                    <span className="text-white">{db.connectionPool}</span>
                  </div>
                )}
                
                {db.activeConnections && (
                  <div className="flex justify-between">
                    <span className="text-purple-300">Active Connections:</span>
                    <span className="text-cyan-400">{db.activeConnections}</span>
                  </div>
                )}
                
                {db.queryTime && (
                  <div className="flex justify-between">
                    <span className="text-purple-300">Avg Query Time:</span>
                    <span className="text-green-400">{db.queryTime}ms</span>
                  </div>
                )}
                
                {db.memory && (
                  <div className="flex justify-between">
                    <span className="text-purple-300">Memory:</span>
                    <span className="text-white">{db.memory}</span>
                  </div>
                )}
                
                {db.hitRate && (
                  <div className="flex justify-between">
                    <span className="text-purple-300">Hit Rate:</span>
                    <span className="text-green-400">{db.hitRate}%</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* API Endpoints */}
      <div className="bg-black/30 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20">
        <h3 className="text-xl font-bold text-white mb-6 flex items-center">
          <Code className="h-5 w-5 mr-2 text-purple-400" />
          API Endpoints Performance
        </h3>
        
        <div className="space-y-4">
          {data.backend.apis.map((api, index) => (
            <div 
              key={index} 
              className={`p-4 bg-white/5 rounded-xl border cursor-pointer transition-all duration-200 hover:bg-white/10 ${
                selectedAPI === index ? 'border-purple-500 bg-purple-500/10' : 'border-gray-500/20'
              }`}
              onClick={() => setSelectedAPI(selectedAPI === index ? null : index)}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <span className={`px-2 py-1 rounded text-xs font-mono ${
                    api.method === 'GET' ? 'bg-blue-500/20 text-blue-400' :
                    api.method === 'POST' ? 'bg-green-500/20 text-green-400' :
                    api.method === 'PUT' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>
                    {api.method}
                  </span>
                  <span className="text-white font-mono">{api.endpoint}</span>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-1">
                    <Clock className="h-3 w-3 text-cyan-400" />
                    <span className="text-cyan-400 text-sm">{api.responseTime}ms</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    {api.errorRate < 1 ? (
                      <CheckCircle className="h-3 w-3 text-green-400" />
                    ) : (
                      <AlertCircle className="h-3 w-3 text-yellow-400" />
                    )}
                    <span className={`text-sm ${api.errorRate < 1 ? 'text-green-400' : 'text-yellow-400'}`}>
                      {api.errorRate}% error
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="text-purple-300">Requests/min:</span>
                  <div className="text-white font-semibold">{api.requestsPerMinute.toLocaleString()}</div>
                </div>
                <div>
                  <span className="text-purple-300">Avg Response:</span>
                  <div className="text-cyan-400 font-semibold">{api.responseTime}ms</div>
                </div>
                <div>
                  <span className="text-purple-300">Success Rate:</span>
                  <div className="text-green-400 font-semibold">{(100 - api.errorRate).toFixed(1)}%</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Middleware & Monitoring */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-black/30 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20">
          <h3 className="text-lg font-bold text-white mb-4 flex items-center">
            <Shield className="h-4 w-4 mr-2 text-purple-400" />
            Middleware Stack
          </h3>
          
          <div className="space-y-3">
            {data.backend.middleware.map((middleware, index) => (
              <div key={index} className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg">
                <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                <span className="text-white text-sm">{middleware}</span>
              </div>
            ))}
          </div>
        </div>
        
        <div className="bg-black/30 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20">
          <h3 className="text-lg font-bold text-white mb-4 flex items-center">
            <Activity className="h-4 w-4 mr-2 text-purple-400" />
            Monitoring Metrics
          </h3>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-purple-300">Alerts (24h):</span>
              <span className="text-yellow-400 font-semibold">{data.backend.monitoring.alertsLast24h}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-purple-300">Avg Response:</span>
              <span className="text-cyan-400 font-semibold">{data.backend.monitoring.avgResponseTime}ms</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-purple-300">Error Rate:</span>
              <span className="text-green-400 font-semibold">{data.backend.monitoring.errorRate}%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BackendDetails;