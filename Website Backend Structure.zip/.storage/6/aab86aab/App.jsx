import React, { useState } from 'react';
import Header from './components/Header';
import UrlAnalyzer from './components/UrlAnalyzer';
import NetworkGraph from './components/NetworkGraph';
import StructurePanel from './components/StructurePanel';
import TechStack from './components/TechStack';
import ConnectionMap from './components/ConnectionMap';
import { analyzeWebsite } from './data/websiteAnalyzer';

function App() {
  const [analysisData, setAnalysisData] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentUrl, setCurrentUrl] = useState('');

  const handleAnalyze = async (url) => {
    setIsAnalyzing(true);
    setCurrentUrl(url);
    
    // Simulate analysis delay
    setTimeout(() => {
      const data = analyzeWebsite(url);
      setAnalysisData(data);
      setIsAnalyzing(false);
    }, 2000);
  };

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <Header />
      
      <main className="flex-1 p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <UrlAnalyzer onAnalyze={handleAnalyze} isAnalyzing={isAnalyzing} />
          
          {isAnalyzing && (
            <div className="flex items-center justify-center py-12">
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-400 mx-auto mb-4"></div>
                <p className="text-white text-lg">Analyzing {currentUrl}...</p>
                <p className="text-purple-300 text-sm">Discovering structure and connections</p>
              </div>
            </div>
          )}
          
          {analysisData && !isAnalyzing && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                <NetworkGraph data={analysisData} />
                <ConnectionMap data={analysisData} />
              </div>
              
              <div className="space-y-6">
                <StructurePanel data={analysisData} />
                <TechStack data={analysisData} />
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;