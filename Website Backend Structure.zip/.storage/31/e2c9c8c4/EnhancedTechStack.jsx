import React, { useState } from 'react';
import { Code2, Database, Server, Palette, Shield, Zap, Globe, Cloud, Cpu, Monitor, Package, GitBranch, Settings, Activity } from 'lucide-react';

const EnhancedTechStack = ({ data }) => {
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [hoveredTech, setHoveredTech] = useState(null);

  const getTechIcon = (category) => {
    switch (category) {
      case 'Frontend': return Code2;
      case 'Backend': return Server;
      case 'Database': return Database;
      case 'Styling': return Palette;
      case 'Security': return Shield;
      case 'Infrastructure': return Cloud;
      case 'DevOps': return Settings;
      case 'Monitoring': return Activity;
      case 'CDN': return Globe;
      case 'Runtime': return Cpu;
      default: return Zap;
    }
  };

  const getTechColor = (category) => {
    switch (category) {
      case 'Frontend': return 'from-blue-500 to-cyan-500';
      case 'Backend': return 'from-green-500 to-emerald-500';
      case 'Database': return 'from-purple-500 to-violet-500';
      case 'Styling': return 'from-pink-500 to-rose-500';
      case 'Security': return 'from-red-500 to-orange-500';
      case 'Infrastructure': return 'from-yellow-500 to-amber-500';
      case 'DevOps': return 'from-indigo-500 to-blue-500';
      case 'Monitoring': return 'from-teal-500 to-cyan-500';
      case 'CDN': return 'from-orange-500 to-red-500';
      case 'Runtime': return 'from-gray-500 to-slate-500';
      default: return 'from-gray-500 to-slate-500';
    }
  };

  const getPopularityScore = (techName) => {
    const popularityMap = {
      'React': 95, 'Vue': 85, 'Angular': 80, 'jQuery': 70,
      'Node.js': 90, 'Express': 85, 'Django': 75, 'Ruby on Rails': 70,
      'PostgreSQL': 88, 'MongoDB': 82, 'Redis': 85, 'MySQL': 80,
      'Docker': 92, 'Kubernetes': 88, 'AWS': 95, 'Azure': 85,
      'TypeScript': 89, 'JavaScript': 98, 'Python': 92, 'Java': 85
    };
    return popularityMap[techName] || Math.floor(Math.random() * 40) + 60;
  };

  const getSecurityScore = (techName) => {
    const securityMap = {
      'React': 85, 'Vue': 88, 'Angular': 90, 'jQuery': 65,
      'Node.js': 80, 'Express': 75, 'Django': 92, 'Ruby on Rails': 88,
      'PostgreSQL': 95, 'MongoDB': 82, 'Redis': 85, 'MySQL': 88
    };
    return securityMap[techName] || Math.floor(Math.random() * 30) + 70;
  };

  const getPerformanceScore = (techName) => {
    const performanceMap = {
      'React': 88, 'Vue': 90, 'Angular': 82, 'jQuery': 95,
      'Node.js': 85, 'Express': 88, 'Django': 80, 'Ruby on Rails': 75,
      'PostgreSQL': 92, 'MongoDB': 85, 'Redis': 98, 'MySQL': 88
    };
    return performanceMap[techName] || Math.floor(Math.random() * 30) + 70;
  };

  const renderTechDetails = (tech) => {
    const popularity = getPopularityScore(tech.name);
    const security = getSecurityScore(tech.name);
    const performance = getPerformanceScore(tech.name);

    return (
      <div className="absolute z-50 top-full left-1/2 transform -translate-x-1/2 mt-2 w-80 bg-black/95 backdrop-blur-lg border border-purple-500/30 rounded-xl p-4 shadow-2xl">
        <div className="text-white font-semibold mb-3 flex items-center space-x-2">
          <Package className="h-4 w-4 text-purple-400" />
          <span>{tech.name}</span>
          <span className="text-xs bg-purple-500/20 text-purple-300 px-2 py-1 rounded">v{tech.version}</span>
        </div>
        
        <div className="space-y-3">
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-purple-300">Popularity</span>
              <span className="text-white">{popularity}%</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-blue-500 to-cyan-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${popularity}%` }}
              ></div>
            </div>
          </div>
          
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-purple-300">Security Score</span>
              <span className="text-white">{security}%</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-green-500 to-emerald-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${security}%` }}
              ></div>
            </div>
          </div>
          
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-purple-300">Performance</span>
              <span className="text-white">{performance}%</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-yellow-500 to-orange-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${performance}%` }}
              ></div>
            </div>
          </div>
        </div>
        
        <div className="mt-3 pt-3 border-t border-purple-500/20">
          <div className="text-xs text-gray-400 space-y-1">
            <div>License: MIT</div>
            <div>Last Updated: {new Date().toLocaleDateString()}</div>
            <div>Bundle Size: {Math.floor(Math.random() * 500) + 50}KB</div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-black/30 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white flex items-center">
          <Code2 className="h-5 w-5 mr-2 text-purple-400" />
          Technology Stack Analysis
        </h3>
        <div className="text-sm text-purple-300">
          {Object.keys(data.techStack).length} categories detected
        </div>
      </div>
      
      {/* Technology Categories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {Object.entries(data.techStack).map(([category, technologies]) => {
          const Icon = getTechIcon(category);
          const gradient = getTechColor(category);
          const isSelected = selectedCategory === category;
          
          return (
            <div
              key={category}
              className={`p-4 rounded-xl border cursor-pointer transition-all duration-300 hover:scale-105 ${
                isSelected 
                  ? 'border-purple-500 bg-purple-500/20 shadow-lg shadow-purple-500/25' 
                  : 'border-gray-500/20 bg-white/5 hover:border-purple-500/50'
              }`}
              onClick={() => setSelectedCategory(isSelected ? null : category)}
            >
              <div className="flex items-center space-x-3 mb-3">
                <div className={`w-10 h-10 bg-gradient-to-r ${gradient} rounded-lg flex items-center justify-center`}>
                  <Icon className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h4 className="text-white font-semibold">{category}</h4>
                  <p className="text-purple-300 text-sm">{technologies.length} technologies</p>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-1">
                {technologies.slice(0, 3).map((tech, index) => (
                  <span key={index} className="text-xs bg-white/10 text-gray-300 px-2 py-1 rounded">
                    {tech.name}
                  </span>
                ))}
                {technologies.length > 3 && (
                  <span className="text-xs text-purple-400">+{technologies.length - 3} more</span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Detailed Technology View */}
      {selectedCategory && (
        <div className="mb-8 p-6 bg-white/5 rounded-xl border border-purple-500/20">
          <div className="flex items-center space-x-3 mb-6">
            {React.createElement(getTechIcon(selectedCategory), { 
              className: `h-6 w-6 text-purple-400` 
            })}
            <h4 className="text-xl font-bold text-white">{selectedCategory} Technologies</h4>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {data.techStack[selectedCategory].map((tech, index) => (
              <div
                key={index}
                className="relative p-4 bg-white/5 rounded-lg border border-gray-500/20 hover:border-purple-500/50 transition-all duration-200 cursor-pointer group"
                onMouseEnter={() => setHoveredTech(`${selectedCategory}-${index}`)}
                onMouseLeave={() => setHoveredTech(null)}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-cyan-500 rounded-lg flex items-center justify-center">
                      <GitBranch className="h-4 w-4 text-white" />
                    </div>
                    <span className="text-white font-medium">{tech.name}</span>
                  </div>
                  <span className="text-xs bg-purple-500/20 text-purple-300 px-2 py-1 rounded">
                    v{tech.version}
                  </span>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-purple-300">Popularity:</span>
                    <span className="text-cyan-400">{getPopularityScore(tech.name)}%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-purple-300">Security:</span>
                    <span className="text-green-400">{getSecurityScore(tech.name)}%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-purple-300">Performance:</span>
                    <span className="text-yellow-400">{getPerformanceScore(tech.name)}%</span>
                  </div>
                </div>

                {hoveredTech === `${selectedCategory}-${index}` && renderTechDetails(tech)}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Technology Stack Visualization */}
      <div className="mb-6">
        <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
          <Monitor className="h-4 w-4 mr-2 text-purple-400" />
          Stack Architecture Visualization
        </h4>
        
        <div className="relative h-64 bg-slate-900/50 rounded-xl overflow-hidden p-4">
          <svg className="w-full h-full">
            {/* Layer connections */}
            <defs>
              <linearGradient id="stackGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.8" />
                <stop offset="50%" stopColor="#06b6d4" stopOpacity="0.6" />
                <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.8" />
              </linearGradient>
            </defs>
            
            {/* Frontend Layer */}
            <rect x="50" y="20" width="200" height="40" rx="8" fill="url(#stackGradient)" opacity="0.3" />
            <text x="150" y="45" textAnchor="middle" fill="#ffffff" fontSize="14" fontWeight="bold">Frontend Layer</text>
            
            {/* Backend Layer */}
            <rect x="50" y="80" width="200" height="40" rx="8" fill="url(#stackGradient)" opacity="0.5" />
            <text x="150" y="105" textAnchor="middle" fill="#ffffff" fontSize="14" fontWeight="bold">Backend Layer</text>
            
            {/* Database Layer */}
            <rect x="50" y="140" width="200" height="40" rx="8" fill="url(#stackGradient)" opacity="0.7" />
            <text x="150" y="165" textAnchor="middle" fill="#ffffff" fontSize="14" fontWeight="bold">Database Layer</text>
            
            {/* Infrastructure Layer */}
            <rect x="50" y="200" width="200" height="40" rx="8" fill="url(#stackGradient)" opacity="0.9" />
            <text x="150" y="225" textAnchor="middle" fill="#ffffff" fontSize="14" fontWeight="bold">Infrastructure</text>
            
            {/* Connection lines */}
            <line x1="150" y1="60" x2="150" y2="80" stroke="#8b5cf6" strokeWidth="2" />
            <line x1="150" y1="120" x2="150" y2="140" stroke="#8b5cf6" strokeWidth="2" />
            <line x1="150" y1="180" x2="150" y2="200" stroke="#8b5cf6" strokeWidth="2" />
            
            {/* Technology bubbles */}
            {Object.entries(data.techStack).map(([category, techs], categoryIndex) => 
              techs.slice(0, 2).map((tech, techIndex) => {
                const x = 300 + (techIndex * 80);
                const y = 40 + (categoryIndex * 60);
                return (
                  <g key={`${category}-${techIndex}`}>
                    <circle cx={x} cy={y} r="20" fill={`url(#stackGradient)`} opacity="0.8" />
                    <text x={x} y={y + 4} textAnchor="middle" fill="#ffffff" fontSize="10" fontWeight="bold">
                      {tech.name.substring(0, 6)}
                    </text>
                  </g>
                );
              })
            )}
          </svg>
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="text-center p-3 bg-green-500/20 rounded-lg">
          <div className="text-2xl font-bold text-green-400">{data.performance.loadTime}ms</div>
          <div className="text-xs text-green-300">Load Time</div>
        </div>
        <div className="text-center p-3 bg-blue-500/20 rounded-lg">
          <div className="text-2xl font-bold text-blue-400">{data.performance.score}/100</div>
          <div className="text-xs text-blue-300">Performance</div>
        </div>
        <div className="text-center p-3 bg-purple-500/20 rounded-lg">
          <div className="text-2xl font-bold text-purple-400">{Object.keys(data.techStack).length}</div>
          <div className="text-xs text-purple-300">Tech Categories</div>
        </div>
        <div className="text-center p-3 bg-cyan-500/20 rounded-lg">
          <div className="text-2xl font-bold text-cyan-400">
            {Object.values(data.techStack).reduce((total, techs) => total + techs.length, 0)}
          </div>
          <div className="text-xs text-cyan-300">Total Technologies</div>
        </div>
      </div>
    </div>
  );
};

export default EnhancedTechStack;