import React from 'react';
import { Globe, Network, Search } from 'lucide-react';

const Header = () => {
  return (
    <header className="bg-black/20 backdrop-blur-lg border-b border-purple-500/20">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Globe className="h-8 w-8 text-purple-400" />
              <Network className="h-4 w-4 text-cyan-400 absolute -top-1 -right-1" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">WebStruct</h1>
              <p className="text-purple-300 text-sm">Website Structure Analyzer</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 text-purple-300">
              <Search className="h-4 w-4" />
              <span className="text-sm">Analyze any website</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;