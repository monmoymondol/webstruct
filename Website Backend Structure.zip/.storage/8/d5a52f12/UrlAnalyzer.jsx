import React, { useState } from 'react';
import { Search, Globe, Zap } from 'lucide-react';

const UrlAnalyzer = ({ onAnalyze, isAnalyzing }) => {
  const [url, setUrl] = useState('');
  const [error, setError] = useState('');

  const validateUrl = (url) => {
    try {
      new URL(url.startsWith('http') ? url : `https://${url}`);
      return true;
    } catch {
      return false;
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    
    if (!url.trim()) {
      setError('Please enter a URL');
      return;
    }
    
    if (!validateUrl(url)) {
      setError('Please enter a valid URL');
      return;
    }
    
    const formattedUrl = url.startsWith('http') ? url : `https://${url}`;
    onAnalyze(formattedUrl);
  };

  const exampleSites = [
    'github.com',
    'stackoverflow.com',
    'netflix.com',
    'amazon.com'
  ];

  return (
    <div className="bg-black/30 backdrop-blur-lg rounded-2xl p-8 border border-purple-500/20">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-white mb-2">Analyze Website Structure</h2>
        <p className="text-purple-300">Discover the hidden architecture and connections of any website</p>
      </div>
      
      <form onSubmit={handleSubmit} className="max-w-2xl mx-auto">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <Globe className="h-5 w-5 text-purple-400" />
          </div>
          
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="Enter website URL (e.g., example.com)"
            className="w-full pl-12 pr-32 py-4 bg-white/10 border border-purple-500/30 rounded-xl text-white placeholder-purple-300 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            disabled={isAnalyzing}
          />
          
          <button
            type="submit"
            disabled={isAnalyzing}
            className="absolute inset-y-0 right-2 px-6 bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg text-white font-medium flex items-center space-x-2 transition-all duration-200"
          >
            {isAnalyzing ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                <span>Analyzing</span>
              </>
            ) : (
              <>
                <Search className="h-4 w-4" />
                <span>Analyze</span>
              </>
            )}
          </button>
        </div>
        
        {error && (
          <p className="text-red-400 text-sm mt-2 text-center">{error}</p>
        )}
      </form>
      
      <div className="mt-8">
        <p className="text-purple-300 text-sm text-center mb-4">Try these examples:</p>
        <div className="flex flex-wrap justify-center gap-3">
          {exampleSites.map((site) => (
            <button
              key={site}
              onClick={() => setUrl(site)}
              className="px-4 py-2 bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/30 rounded-lg text-purple-300 text-sm transition-colors duration-200 flex items-center space-x-2"
              disabled={isAnalyzing}
            >
              <Zap className="h-3 w-3" />
              <span>{site}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default UrlAnalyzer;