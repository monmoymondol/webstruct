import React, { useState } from 'react';
import { Network, Zap, Clock, Activity, TrendingUp, Eye } from 'lucide-react';

const NetworkTopology = ({ data }) => {
  const [selectedNode, setSelectedNode] = useState(null);
  const [viewMode, setViewMode] = useState('topology'); // topology, traffic, security

  const getTrafficIntensity = (traffic) => {
    if (traffic > 80) return 'high';
    if (traffic > 50) return 'medium';
    return 'low';
  };

  const getTrafficColor = (intensity) => {
    switch (intensity) {
      case 'high': return 'border-red-400 shadow-red-400/50';
      case 'medium': return 'border-yellow-400 shadow-yellow-400/50';
      case 'low': return 'border-green-400 shadow-green-400/50';
      default: return 'border-purple-400 shadow-purple-400/50';
    }
  };

  const viewModes = [
    { id: 'topology', label: 'Network Topology', icon: Network },
    { id: 'traffic', label: 'Traffic Flow', icon: Activity },
    { id: 'security', label: 'Security View', icon: Eye }
  ];

  return (
    <div className="bg-black/30 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white flex items-center">
          <Network className="h-5 w-5 mr-2 text-purple-400" />
          Advanced Network Topology
        </h3>
        
        <div className="flex space-x-2">
          {viewModes.map((mode) => {
            const Icon = mode.icon;
            return (
              <button
                key={mode.id}
                onClick={() => setViewMode(mode.id)}
                className={`px-3 py-1 rounded-lg text-xs flex items-center space-x-1 transition-colors duration-200 ${
                  viewMode === mode.id
                    ? 'bg-purple-600 text-white'
                    : 'bg-white/10 text-purple-300 hover:bg-white/20'
                }`}
              >
                <Icon className="h-3 w-3" />
                <span>{mode.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="relative h-96 bg-slate-900/50 rounded-xl overflow-hidden mb-6">
        {/* Enhanced Network Visualization */}
        <svg className="w-full h-full">
          {/* Connection lines with traffic visualization */}
          {data.networkTopology.connections.map((conn, index) => {
            const intensity = getTrafficIntensity(conn.traffic);
            const strokeWidth = intensity === 'high' ? 4 : intensity === 'medium' ? 3 : 2;
            const opacity = viewMode === 'traffic' ? conn.traffic / 100 : 0.8;
            
            return (
              <g key={index}>
                <line
                  x1={conn.from.x}
                  y1={conn.from.y}
                  x2={conn.to.x}
                  y2={conn.to.y}
                  stroke={viewMode === 'security' && conn.encrypted ? '#10b981' : '#8b5cf6'}
                  strokeWidth={strokeWidth}
                  opacity={opacity}
                  className="animate-pulse"
                />
                
                {/* Traffic flow animation */}
                {viewMode === 'traffic' && (
                  <circle r="3" fill="#06b6d4" opacity="0.8">
                    <animateMotion
                      dur="3s"
                      repeatCount="indefinite"
                      path={`M${conn.from.x},${conn.from.y} L${conn.to.x},${conn.to.y}`}
                    />
                  </circle>
                )}
                
                {/* Security indicators */}
                {viewMode === 'security' && !conn.encrypted && (
                  <text
                    x={(conn.from.x + conn.to.x) / 2}
                    y={(conn.from.y + conn.to.y) / 2}
                    fill="#ef4444"
                    fontSize="10"
                    textAnchor="middle"
                  >
                    ⚠
                  </text>
                )}
              </g>
            );
          })}
          
          <defs>
            <filter id="glow">
              <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
              <feMerge> 
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
        </svg>
        
        {/* Enhanced Nodes */}
        {data.networkTopology.nodes.map((node, index) => {
          const isSelected = selectedNode?.id === node.id;
          const trafficIntensity = getTrafficIntensity(node.traffic || 0);
          const trafficColorClass = getTrafficColor(trafficIntensity);
          
          return (
            <div
              key={index}
              className={`absolute transform -translate-x-1/2 -translate-y-1/2 group cursor-pointer transition-all duration-300 ${
                isSelected ? 'scale-125 z-10' : 'hover:scale-110'
              }`}
              style={{ left: `${node.x}px`, top: `${node.y}px` }}
              onClick={() => setSelectedNode(isSelected ? null : node)}
            >
              <div className={`w-16 h-16 bg-gradient-to-br ${node.gradient} rounded-full flex items-center justify-center shadow-lg border-2 ${
                viewMode === 'traffic' ? trafficColorClass : 'border-purple-400/50'
              } ${isSelected ? 'shadow-2xl' : ''}`}
              style={{ filter: isSelected ? 'url(#glow)' : 'none' }}>
                <node.icon className="h-8 w-8 text-white" />
                
                {/* Status indicators */}
                <div className="absolute -top-1 -right-1">
                  {viewMode === 'security' && node.secure && (
                    <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    </div>
                  )}
                  {viewMode === 'traffic' && (
                    <div className={`w-3 h-3 rounded-full ${
                      trafficIntensity === 'high' ? 'bg-red-400' :
                      trafficIntensity === 'medium' ? 'bg-yellow-400' : 'bg-green-400'
                    } animate-pulse`}></div>
                  )}
                </div>
              </div>
              
              {/* Enhanced tooltip */}
              <div className={`absolute top-full mt-3 left-1/2 transform -translate-x-1/2 transition-all duration-200 ${
                isSelected ? 'opacity-100 scale-100' : 'opacity-0 scale-95 group-hover:opacity-100 group-hover:scale-100'
              }`}>
                <div className="bg-black/90 backdrop-blur-lg px-4 py-3 rounded-lg text-white text-xs whitespace-nowrap border border-purple-500/30 shadow-xl">
                  <div className="font-semibold text-purple-300 mb-1">{node.label}</div>
                  <div className="space-y-1 text-gray-300">
                    <div>Type: {node.type}</div>
                    <div>Status: <span className="text-green-400">{node.status}</span></div>
                    {viewMode === 'traffic' && (
                      <div>Traffic: <span className="text-cyan-400">{node.traffic}%</span></div>
                    )}
                    {viewMode === 'security' && (
                      <div>Security: <span className={node.secure ? 'text-green-400' : 'text-red-400'}>
                        {node.secure ? 'Secure' : 'Vulnerable'}
                      </span></div>
                    )}
                    <div>Response: {node.responseTime}ms</div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Network Statistics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 bg-white/5 rounded-xl">
          <div className="flex items-center space-x-2 mb-2">
            <TrendingUp className="h-4 w-4 text-green-400" />
            <span className="text-sm text-purple-300">Throughput</span>
          </div>
          <div className="text-xl font-bold text-white">{data.networkTopology.stats.throughput}</div>
          <div className="text-xs text-green-400">+12% from baseline</div>
        </div>
        
        <div className="p-4 bg-white/5 rounded-xl">
          <div className="flex items-center space-x-2 mb-2">
            <Clock className="h-4 w-4 text-blue-400" />
            <span className="text-sm text-purple-300">Avg Latency</span>
          </div>
          <div className="text-xl font-bold text-white">{data.networkTopology.stats.latency}ms</div>
          <div className="text-xs text-blue-400">Within normal range</div>
        </div>
        
        <div className="p-4 bg-white/5 rounded-xl">
          <div className="flex items-center space-x-2 mb-2">
            <Zap className="h-4 w-4 text-yellow-400" />
            <span className="text-sm text-purple-300">Active Connections</span>
          </div>
          <div className="text-xl font-bold text-white">{data.networkTopology.stats.connections}</div>
          <div className="text-xs text-yellow-400">Peak: {data.networkTopology.stats.peakConnections}</div>
        </div>
        
        <div className="p-4 bg-white/5 rounded-xl">
          <div className="flex items-center space-x-2 mb-2">
            <Activity className="h-4 w-4 text-purple-400" />
            <span className="text-sm text-purple-300">Health Score</span>
          </div>
          <div className="text-xl font-bold text-white">{data.networkTopology.stats.healthScore}%</div>
          <div className="text-xs text-purple-400">Excellent</div>
        </div>
      </div>
    </div>
  );
};

export default NetworkTopology;