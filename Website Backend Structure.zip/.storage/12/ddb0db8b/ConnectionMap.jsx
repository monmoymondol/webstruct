import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Activity, Globe, Server, Database } from 'lucide-react';

const ConnectionMap = ({ data }) => {
  const COLORS = ['#8b5cf6', '#06b6d4', '#10b981', '#f59e0b', '#ef4444'];

  return (
    <div className="bg-black/30 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20">
      <h3 className="text-xl font-bold text-white mb-6 flex items-center">
        <Activity className="h-5 w-5 mr-2 text-purple-400" />
        Connection Analysis
      </h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Request Types Chart */}
        <div className="space-y-4">
          <h4 className="text-lg font-semibold text-white">Request Distribution</h4>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.requestTypes}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis 
                  dataKey="name" 
                  stroke="#9ca3af" 
                  fontSize={12}
                />
                <YAxis stroke="#9ca3af" fontSize={12} />
                <Bar 
                  dataKey="count" 
                  fill="url(#barGradient)"
                  radius={[4, 4, 0, 0]}
                />
                <defs>
                  <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.3}/>
                  </linearGradient>
                </defs>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        {/* Connection Types Pie Chart */}
        <div className="space-y-4">
          <h4 className="text-lg font-semibold text-white">Connection Types</h4>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data.connectionTypes}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {data.connectionTypes.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap gap-2">
            {data.connectionTypes.map((entry, index) => (
              <div key={entry.name} className="flex items-center space-x-2 text-xs">
                <div 
                  className="w-3 h-3 rounded-full" 
                  style={{ backgroundColor: COLORS[index % COLORS.length] }}
                ></div>
                <span className="text-purple-300">{entry.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* Backend Services */}
      <div className="mt-6 pt-6 border-t border-purple-500/20">
        <h4 className="text-lg font-semibold text-white mb-4">Detected Backend Services</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {data.backendServices.map((service, index) => {
            const getServiceIcon = (type) => {
              switch (type) {
                case 'API': return Server;
                case 'Database': return Database;
                case 'CDN': return Globe;
                default: return Activity;
              }
            };
            
            const Icon = getServiceIcon(service.type);
            
            return (
              <div key={index} className="p-4 bg-white/5 rounded-xl hover:bg-white/10 transition-colors duration-200">
                <div className="flex items-center space-x-3 mb-2">
                  <div className="w-8 h-8 bg-purple-500/20 rounded-lg flex items-center justify-center">
                    <Icon className="h-4 w-4 text-purple-400" />
                  </div>
                  <div>
                    <div className="text-white font-medium text-sm">{service.name}</div>
                    <div className="text-purple-300 text-xs">{service.type}</div>
                  </div>
                </div>
                <div className="text-xs text-gray-400 font-mono">{service.endpoint}</div>
                <div className="mt-2 flex items-center justify-between">
                  <span className={`text-xs px-2 py-1 rounded ${
                    service.status === 'active' 
                      ? 'bg-green-500/20 text-green-400' 
                      : 'bg-yellow-500/20 text-yellow-400'
                  }`}>
                    {service.status}
                  </span>
                  <span className="text-xs text-cyan-400">{service.responseTime}ms</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ConnectionMap;