export const analyzeWebsite = (url) => {
  // Extract domain from URL
  const domain = new URL(url).hostname;
  
  // Generate realistic mock data based on the domain
  const generateMockData = (domain) => {
    const isPopularSite = ['github.com', 'stackoverflow.com', 'netflix.com', 'amazon.com'].includes(domain);
    
    return {
      domain,
      url,
      timestamp: new Date().toISOString(),
      
      // Network nodes for visualization
      nodes: [
        { id: 'main', type: 'main', label: domain, x: 200, y: 150 },
        { id: 'api', type: 'api', label: `api.${domain}`, x: 350, y: 100 },
        { id: 'cdn', type: 'cdn', label: `cdn.${domain}`, x: 350, y: 200 },
        { id: 'db', type: 'database', label: 'Database', x: 500, y: 150 },
        { id: 'auth', type: 'security', label: 'Auth Service', x: 200, y: 50 },
        { id: 'cache', type: 'api', label: 'Cache Layer', x: 200, y: 250 },
      ],
      
      // Connections between nodes
      connections: [
        { from: { x: 200, y: 150 }, to: { x: 350, y: 100 } },
        { from: { x: 200, y: 150 }, to: { x: 350, y: 200 } },
        { from: { x: 350, y: 100 }, to: { x: 500, y: 150 } },
        { from: { x: 200, y: 150 }, to: { x: 200, y: 50 } },
        { from: { x: 200, y: 150 }, to: { x: 200, y: 250 } },
      ],
      
      // Site structure information
      structure: {
        pages: isPopularSite ? Math.floor(Math.random() * 1000) + 500 : Math.floor(Math.random() * 100) + 20,
        externalLinks: isPopularSite ? Math.floor(Math.random() * 500) + 200 : Math.floor(Math.random() * 50) + 10,
        mediaFiles: isPopularSite ? Math.floor(Math.random() * 2000) + 1000 : Math.floor(Math.random() * 200) + 50,
        scripts: isPopularSite ? Math.floor(Math.random() * 100) + 50 : Math.floor(Math.random() * 30) + 10,
      },
      
      // Detected subdomains
      subdomains: generateSubdomains(domain, isPopularSite),
      
      // Technology stack
      techStack: generateTechStack(domain, isPopularSite),
      
      // Performance metrics
      performance: {
        loadTime: isPopularSite ? Math.floor(Math.random() * 500) + 200 : Math.floor(Math.random() * 1000) + 500,
        score: isPopularSite ? Math.floor(Math.random() * 20) + 80 : Math.floor(Math.random() * 40) + 60,
      },
      
      // Request types for charts
      requestTypes: [
        { name: 'HTML', count: Math.floor(Math.random() * 50) + 20 },
        { name: 'CSS', count: Math.floor(Math.random() * 30) + 10 },
        { name: 'JS', count: Math.floor(Math.random() * 40) + 15 },
        { name: 'Images', count: Math.floor(Math.random() * 100) + 50 },
        { name: 'API', count: Math.floor(Math.random() * 60) + 30 },
      ],
      
      // Connection types for pie chart
      connectionTypes: [
        { name: 'HTTPS', value: 70 },
        { name: 'WebSocket', value: 15 },
        { name: 'API Calls', value: 10 },
        { name: 'CDN', value: 5 },
      ],
      
      // Backend services
      backendServices: generateBackendServices(domain, isPopularSite),
    };
  };
  
  return generateMockData(domain);
};

const generateSubdomains = (domain, isPopular) => {
  const commonSubdomains = ['www', 'api', 'cdn', 'static', 'assets', 'admin', 'auth', 'mail'];
  const popularSubdomains = ['blog', 'docs', 'support', 'status', 'dev', 'staging', 'mobile', 'app'];
  
  const subdomains = commonSubdomains.map(sub => `${sub}.${domain}`);
  
  if (isPopular) {
    subdomains.push(...popularSubdomains.map(sub => `${sub}.${domain}`));
  }
  
  return subdomains.slice(0, Math.floor(Math.random() * 8) + 4);
};

const generateTechStack = (domain, isPopular) => {
  const techStacks = {
    'github.com': {
      Frontend: [
        { name: 'React', version: '18.2.0' },
        { name: 'TypeScript', version: '4.9.5' },
        { name: 'Webpack', version: '5.75.0' },
      ],
      Backend: [
        { name: 'Ruby on Rails', version: '7.0.4' },
        { name: 'Node.js', version: '18.12.1' },
        { name: 'Go', version: '1.19.4' },
      ],
      Database: [
        { name: 'PostgreSQL', version: '14.6' },
        { name: 'Redis', version: '7.0.5' },
        { name: 'Elasticsearch', version: '8.5.3' },
      ],
      Styling: [
        { name: 'Primer CSS', version: '21.0.7' },
        { name: 'SCSS', version: '1.56.1' },
      ],
      Security: [
        { name: 'OAuth 2.0', version: '2.1' },
        { name: 'JWT', version: '9.0.0' },
      ],
    },
    'stackoverflow.com': {
      Frontend: [
        { name: 'jQuery', version: '3.6.0' },
        { name: 'TypeScript', version: '4.8.4' },
        { name: 'Stencil', version: '2.18.1' },
      ],
      Backend: [
        { name: 'ASP.NET Core', version: '6.0' },
        { name: 'C#', version: '10.0' },
      ],
      Database: [
        { name: 'SQL Server', version: '2019' },
        { name: 'Redis', version: '6.2.7' },
      ],
      Styling: [
        { name: 'LESS', version: '4.1.3' },
        { name: 'Bootstrap', version: '5.2.2' },
      ],
      Security: [
        { name: 'OpenID Connect', version: '1.0' },
        { name: 'ASP.NET Identity', version: '6.0' },
      ],
    },
    default: {
      Frontend: [
        { name: 'React', version: '18.2.0' },
        { name: 'JavaScript', version: 'ES2022' },
      ],
      Backend: [
        { name: 'Node.js', version: '18.12.1' },
        { name: 'Express', version: '4.18.2' },
      ],
      Database: [
        { name: 'MongoDB', version: '6.0.3' },
        { name: 'Redis', version: '7.0.5' },
      ],
      Styling: [
        { name: 'CSS3', version: '3.0' },
        { name: 'Tailwind CSS', version: '3.2.4' },
      ],
      Security: [
        { name: 'JWT', version: '9.0.0' },
        { name: 'bcrypt', version: '5.1.0' },
      ],
    },
  };
  
  return techStacks[domain] || techStacks.default;
};

const generateBackendServices = (domain, isPopular) => {
  const baseServices = [
    {
      name: 'Main API',
      type: 'API',
      endpoint: `/api/v1`,
      status: 'active',
      responseTime: Math.floor(Math.random() * 100) + 50,
    },
    {
      name: 'Authentication',
      type: 'API',
      endpoint: `/auth`,
      status: 'active',
      responseTime: Math.floor(Math.random() * 50) + 20,
    },
    {
      name: 'CDN',
      type: 'CDN',
      endpoint: `cdn.${domain}`,
      status: 'active',
      responseTime: Math.floor(Math.random() * 30) + 10,
    },
    {
      name: 'Database',
      type: 'Database',
      endpoint: 'Internal',
      status: 'active',
      responseTime: Math.floor(Math.random() * 20) + 5,
    },
  ];
  
  if (isPopular) {
    baseServices.push(
      {
        name: 'Search API',
        type: 'API',
        endpoint: `/search/v2`,
        status: 'active',
        responseTime: Math.floor(Math.random() * 80) + 40,
      },
      {
        name: 'Analytics',
        type: 'API',
        endpoint: `/analytics`,
        status: 'active',
        responseTime: Math.floor(Math.random() * 60) + 30,
      },
      {
        name: 'Cache Layer',
        type: 'Database',
        endpoint: 'Redis Cluster',
        status: 'active',
        responseTime: Math.floor(Math.random() * 10) + 2,
      }
    );
  }
  
  return baseServices;
};