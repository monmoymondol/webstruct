import React, { useState } from 'react';
import Header from './components/Header';
import UrlAnalyzer from './components/UrlAnalyzer';
import NetworkGraph from './components/NetworkGraph';
import StructurePanel from './components/StructurePanel';
import TechStack from './components/TechStack';
import ConnectionMap from './components/ConnectionMap';
import DetailedAnalysis from './components/DetailedAnalysis';
import NetworkTopology from './components/NetworkTopology';
import { analyzeWebsite } from './data/websiteAnalyzer';

function App() {
  const [analysisData, setAnalysisData] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentUrl, setCurrentUrl] = useState('');
  const [activeTab, setActiveTab] = useState('overview');

  const handleAnalyze = async (url) => {
    setIsAnalyzing(true);
    setCurrentUrl(url);
    
    // Simulate analysis delay
    setTimeout(() => {
      const data = analyzeWebsite(url);
      setAnalysisData(data);
      setIsAnalyzing(false);
    }, 3000);
  };

  const tabs = [
    { id: 'overview', label: 'Overview', description: 'General structure and metrics' },
    { id: 'topology', label: 'Network Topology', description: 'Advanced network visualization' },
    { id: 'detailed', label: 'Deep Analysis', description: 'Comprehensive security & performance analysis' }
  ];

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <Header />
      
      <main className="flex-1 p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <UrlAnalyzer onAnalyze={handleAnalyze} isAnalyzing={isAnalyzing} />
          
          {isAnalyzing && (
            <div className="flex items-center justify-center py-12">
              <div className="text-center">
                <div className="relative">
                  <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-purple-400 mx-auto mb-4"></div>
                  <div className="absolute inset-0 animate-ping rounded-full h-16 w-16 border border-purple-400/30 mx-auto"></div>
                </div>
                <p className="text-white text-xl font-semibold">Analyzing {currentUrl}...</p>
                <div className="mt-2 space-y-1 text-purple-300 text-sm">
                  <p>🔍 Discovering structure and connections</p>
                  <p>🛡️ Analyzing security configurations</p>
                  <p>⚡ Measuring performance metrics</p>
                  <p>🌐 Mapping network topology</p>
                </div>
              </div>
            </div>
          )}
          
          {analysisData && !isAnalyzing && (
            <>
              {/* Tab Navigation */}
              <div className="bg-black/30 backdrop-blur-lg rounded-2xl p-2 border border-purple-500/20">
                <div className="flex space-x-2">
                  {tabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`flex-1 px-4 py-3 rounded-xl transition-all duration-200 ${
                        activeTab === tab.id
                          ? 'bg-gradient-to-r from-purple-600 to-cyan-600 text-white shadow-lg'
                          : 'text-purple-300 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      <div className="text-sm font-semibold">{tab.label}</div>
                      <div className="text-xs opacity-80">{tab.description}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Tab Content */}
              {activeTab === 'overview' && (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2 space-y-6">
                    <NetworkGraph data={analysisData} />
                    <ConnectionMap data={analysisData} />
                  </div>
                  
                  <div className="space-y-6">
                    <StructurePanel data={analysisData} />
                    <TechStack data={analysisData} />
                  </div>
                </div>
              )}

              {activeTab === 'topology' && (
                <NetworkTopology data={analysisData} />
              )}

              {activeTab === 'detailed' && (
                <DetailedAnalysis data={analysisData} />
              )}
            </>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;