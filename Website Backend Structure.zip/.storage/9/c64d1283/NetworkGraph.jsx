import React from 'react';
import { Server, Database, Globe, Shield, Zap, Cloud } from 'lucide-react';

const NetworkGraph = ({ data }) => {
  const getNodeIcon = (type) => {
    switch (type) {
      case 'main': return Globe;
      case 'api': return Server;
      case 'database': return Database;
      case 'cdn': return Cloud;
      case 'security': return Shield;
      default: return Zap;
    }
  };

  const getNodeColor = (type) => {
    switch (type) {
      case 'main': return 'from-purple-500 to-pink-500';
      case 'api': return 'from-blue-500 to-cyan-500';
      case 'database': return 'from-green-500 to-emerald-500';
      case 'cdn': return 'from-orange-500 to-yellow-500';
      case 'security': return 'from-red-500 to-rose-500';
      default: return 'from-gray-500 to-slate-500';
    }
  };

  return (
    <div className="bg-black/30 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white">Network Architecture</h3>
        <div className="flex items-center space-x-2 text-purple-300 text-sm">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span>Live Analysis</span>
        </div>
      </div>
      
      <div className="relative h-96 bg-slate-900/50 rounded-xl overflow-hidden">
        <svg className="w-full h-full">
          {/* Connection lines */}
          {data.connections.map((conn, index) => (
            <line
              key={index}
              x1={conn.from.x}
              y1={conn.from.y}
              x2={conn.to.x}
              y2={conn.to.y}
              stroke="url(#connectionGradient)"
              strokeWidth="2"
              className="animate-pulse"
            />
          ))}
          
          {/* Gradient definitions */}
          <defs>
            <linearGradient id="connectionGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.8" />
              <stop offset="50%" stopColor="#06b6d4" stopOpacity="0.6" />
              <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.8" />
            </linearGradient>
          </defs>
        </svg>
        
        {/* Nodes */}
        {data.nodes.map((node, index) => {
          const Icon = getNodeIcon(node.type);
          return (
            <div
              key={index}
              className="absolute transform -translate-x-1/2 -translate-y-1/2 group cursor-pointer"
              style={{ left: `${node.x}px`, top: `${node.y}px` }}
            >
              <div className={`w-16 h-16 bg-gradient-to-br ${getNodeColor(node.type)} rounded-full flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-200`}>
                <Icon className="h-8 w-8 text-white" />
              </div>
              
              {/* Node label */}
              <div className="absolute top-full mt-2 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                <div className="bg-black/80 px-3 py-1 rounded-lg text-white text-xs whitespace-nowrap">
                  {node.label}
                </div>
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Legend */}
      <div className="mt-6 grid grid-cols-2 md:grid-cols-3 gap-4">
        {[
          { type: 'main', label: 'Main Domain', icon: Globe },
          { type: 'api', label: 'API Services', icon: Server },
          { type: 'database', label: 'Database', icon: Database },
          { type: 'cdn', label: 'CDN', icon: Cloud },
          { type: 'security', label: 'Security', icon: Shield },
        ].map(({ type, label, icon: Icon }) => (
          <div key={type} className="flex items-center space-x-2 text-sm">
            <div className={`w-4 h-4 bg-gradient-to-br ${getNodeColor(type)} rounded-full flex items-center justify-center`}>
              <Icon className="h-2 w-2 text-white" />
            </div>
            <span className="text-purple-300">{label}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default NetworkGraph;