import React, { useState } from 'react';
import Header from './components/Header';
import UrlAnalyzer from './components/UrlAnalyzer';
import NetworkGraph from './components/NetworkGraph';
import StructurePanel from './components/StructurePanel';
import TechStack from './components/TechStack';
import ConnectionMap from './components/ConnectionMap';
import DetailedAnalysis from './components/DetailedAnalysis';
import NetworkTopology from './components/NetworkTopology';
import RealTimeAnalyzer from './components/RealTimeAnalyzer';
import BackendDetails from './components/BackendDetails';
import { analyzeWebsite } from './data/websiteAnalyzer';

function App() {
  const [analysisData, setAnalysisData] = useState(null);
  const [realTimeData, setRealTimeData] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentUrl, setCurrentUrl] = useState('');
  const [activeTab, setActiveTab] = useState('overview');

  const handleAnalyze = async (url) => {
    setIsAnalyzing(true);
    setCurrentUrl(url);
    setAnalysisData(null);
    setRealTimeData(null);
  };

  const handleRealTimeAnalysisComplete = (realData) => {
    // Merge real-time data with mock data for comprehensive analysis
    const mockData = analyzeWebsite(currentUrl);
    const enhancedData = {
      ...mockData,
      realTimeData: realData,
      // Override with real data where available
      dns: realData.dns,
      ssl: realData.ssl,
      headers: realData.headers,
      techStack: realData.tech || mockData.techStack,
      performance: realData.performance || mockData.performance,
      security: realData.security || mockData.security,
      backend: realData.backend || mockData.backend
    };
    
    setAnalysisData(enhancedData);
    setRealTimeData(realData);
    setIsAnalyzing(false);
  };

  const tabs = [
    { id: 'overview', label: 'Overview', description: 'General structure and metrics' },
    { id: 'topology', label: 'Network Topology', description: 'Advanced network visualization' },
    { id: 'backend', label: 'Backend Details', description: 'Server infrastructure and APIs' },
    { id: 'detailed', label: 'Deep Analysis', description: 'Comprehensive security & performance analysis' }
  ];

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <Header />
      
      <main className="flex-1 p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <UrlAnalyzer onAnalyze={handleAnalyze} isAnalyzing={isAnalyzing} />
          
          {isAnalyzing && (
            <RealTimeAnalyzer 
              url={currentUrl} 
              onAnalysisComplete={handleRealTimeAnalysisComplete}
            />
          )}
          
          {analysisData && !isAnalyzing && (
            <>
              {/* Enhanced Analysis Summary */}
              <div className="bg-black/30 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold text-white">Analysis Summary</h3>
                  <div className="text-sm text-purple-300">
                    Analyzed: {new Date(analysisData.timestamp).toLocaleString()}
                  </div>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="p-4 bg-green-500/20 rounded-xl border border-green-500/30">
                    <div className="text-2xl font-bold text-green-400">
                      {realTimeData?.ssl?.isValid ? 'A+' : 'B'}
                    </div>
                    <div className="text-sm text-green-300">SSL Grade</div>
                  </div>
                  
                  <div className="p-4 bg-blue-500/20 rounded-xl border border-blue-500/30">
                    <div className="text-2xl font-bold text-blue-400">
                      {realTimeData?.performance?.loadTime || analysisData.performance.loadTime}ms
                    </div>
                    <div className="text-sm text-blue-300">Load Time</div>
                  </div>
                  
                  <div className="p-4 bg-purple-500/20 rounded-xl border border-purple-500/30">
                    <div className="text-2xl font-bold text-purple-400">
                      {realTimeData?.backend?.servers?.length || 3}
                    </div>
                    <div className="text-sm text-purple-300">Servers</div>
                  </div>
                  
                  <div className="p-4 bg-cyan-500/20 rounded-xl border border-cyan-500/30">
                    <div className="text-2xl font-bold text-cyan-400">
                      {realTimeData?.backend?.monitoring?.uptime || '99.9'}%
                    </div>
                    <div className="text-sm text-cyan-300">Uptime</div>
                  </div>
                </div>
              </div>

              {/* Tab Navigation */}
              <div className="bg-black/30 backdrop-blur-lg rounded-2xl p-2 border border-purple-500/20">
                <div className="flex space-x-2">
                  {tabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`flex-1 px-4 py-3 rounded-xl transition-all duration-200 ${
                        activeTab === tab.id
                          ? 'bg-gradient-to-r from-purple-600 to-cyan-600 text-white shadow-lg'
                          : 'text-purple-300 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      <div className="text-sm font-semibold">{tab.label}</div>
                      <div className="text-xs opacity-80">{tab.description}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Tab Content */}
              {activeTab === 'overview' && (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2 space-y-6">
                    <NetworkGraph data={analysisData} />
                    <ConnectionMap data={analysisData} />
                  </div>
                  
                  <div className="space-y-6">
                    <StructurePanel data={analysisData} />
                    <TechStack data={analysisData} />
                  </div>
                </div>
              )}

              {activeTab === 'topology' && (
                <NetworkTopology data={analysisData} />
              )}

              {activeTab === 'backend' && (
                <BackendDetails data={analysisData} />
              )}

              {activeTab === 'detailed' && (
                <DetailedAnalysis data={analysisData} />
              )}
            </>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;