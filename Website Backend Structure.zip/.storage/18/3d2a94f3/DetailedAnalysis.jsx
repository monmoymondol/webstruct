import React, { useState } from 'react';
import { ChevronDown, ChevronRight, Info, AlertTriangle, CheckCircle, XCircle, Globe, Server, Database, Shield, Code, Layers } from 'lucide-react';

const DetailedAnalysis = ({ data }) => {
  const [expandedSections, setExpandedSections] = useState({});

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'high': return 'text-red-400 bg-red-500/20';
      case 'medium': return 'text-yellow-400 bg-yellow-500/20';
      case 'low': return 'text-green-400 bg-green-500/20';
      default: return 'text-blue-400 bg-blue-500/20';
    }
  };

  const getSeverityIcon = (severity) => {
    switch (severity) {
      case 'high': return XCircle;
      case 'medium': return AlertTriangle;
      case 'low': return CheckCircle;
      default: return Info;
    }
  };

  const analysisCategories = [
    {
      id: 'security',
      title: 'Security Analysis',
      icon: Shield,
      color: 'text-red-400',
      items: data.detailedAnalysis.security
    },
    {
      id: 'performance',
      title: 'Performance Deep Dive',
      icon: Server,
      color: 'text-green-400',
      items: data.detailedAnalysis.performance
    },
    {
      id: 'architecture',
      title: 'Architecture Patterns',
      icon: Layers,
      color: 'text-blue-400',
      items: data.detailedAnalysis.architecture
    },
    {
      id: 'apis',
      title: 'API Endpoints Discovery',
      icon: Code,
      color: 'text-purple-400',
      items: data.detailedAnalysis.apis
    },
    {
      id: 'database',
      title: 'Database Analysis',
      icon: Database,
      color: 'text-cyan-400',
      items: data.detailedAnalysis.database
    },
    {
      id: 'infrastructure',
      title: 'Infrastructure Details',
      icon: Globe,
      color: 'text-orange-400',
      items: data.detailedAnalysis.infrastructure
    }
  ];

  return (
    <div className="bg-black/30 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-2xl font-bold text-white flex items-center">
          <Info className="h-6 w-6 mr-3 text-purple-400" />
          Deep Analysis Report
        </h3>
        <div className="text-sm text-purple-300">
          {data.detailedAnalysis.totalFindings} findings discovered
        </div>
      </div>

      <div className="space-y-4">
        {analysisCategories.map((category) => {
          const Icon = category.icon;
          const isExpanded = expandedSections[category.id];
          
          return (
            <div key={category.id} className="border border-purple-500/20 rounded-xl overflow-hidden">
              <button
                onClick={() => toggleSection(category.id)}
                className="w-full p-4 bg-white/5 hover:bg-white/10 transition-colors duration-200 flex items-center justify-between"
              >
                <div className="flex items-center space-x-3">
                  <Icon className={`h-5 w-5 ${category.color}`} />
                  <span className="text-white font-semibold">{category.title}</span>
                  <span className="text-xs bg-purple-500/20 text-purple-300 px-2 py-1 rounded-full">
                    {category.items.length} items
                  </span>
                </div>
                {isExpanded ? (
                  <ChevronDown className="h-4 w-4 text-purple-400" />
                ) : (
                  <ChevronRight className="h-4 w-4 text-purple-400" />
                )}
              </button>
              
              {isExpanded && (
                <div className="p-4 space-y-3 bg-black/20">
                  {category.items.map((item, index) => {
                    const SeverityIcon = getSeverityIcon(item.severity);
                    
                    return (
                      <div key={index} className="p-4 bg-white/5 rounded-lg border-l-4 border-purple-500/50">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <div className={`w-6 h-6 ${getSeverityColor(item.severity)} rounded-full flex items-center justify-center`}>
                              <SeverityIcon className="h-3 w-3" />
                            </div>
                            <h4 className="text-white font-medium">{item.title}</h4>
                          </div>
                          <span className={`text-xs px-2 py-1 rounded ${getSeverityColor(item.severity)}`}>
                            {item.severity.toUpperCase()}
                          </span>
                        </div>
                        
                        <p className="text-purple-200 text-sm mb-3 leading-relaxed">
                          {item.description}
                        </p>
                        
                        {item.details && (
                          <div className="space-y-2">
                            <h5 className="text-cyan-400 text-sm font-semibold">Technical Details:</h5>
                            <ul className="space-y-1">
                              {item.details.map((detail, detailIndex) => (
                                <li key={detailIndex} className="text-gray-300 text-xs flex items-start">
                                  <span className="text-purple-400 mr-2">•</span>
                                  <span>{detail}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                        
                        {item.recommendation && (
                          <div className="mt-3 p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
                            <h5 className="text-blue-400 text-sm font-semibold mb-1">Recommendation:</h5>
                            <p className="text-blue-200 text-xs">{item.recommendation}</p>
                          </div>
                        )}
                        
                        {item.impact && (
                          <div className="mt-2 flex items-center space-x-4 text-xs">
                            <span className="text-purple-300">Impact: <span className="text-white">{item.impact}</span></span>
                            {item.confidence && (
                              <span className="text-purple-300">Confidence: <span className="text-white">{item.confidence}%</span></span>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Summary Statistics */}
      <div className="mt-6 pt-6 border-t border-purple-500/20">
        <h4 className="text-lg font-semibold text-white mb-4">Analysis Summary</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-3 bg-red-500/20 rounded-lg">
            <div className="text-2xl font-bold text-red-400">{data.detailedAnalysis.summary.high}</div>
            <div className="text-xs text-red-300">High Priority</div>
          </div>
          <div className="text-center p-3 bg-yellow-500/20 rounded-lg">
            <div className="text-2xl font-bold text-yellow-400">{data.detailedAnalysis.summary.medium}</div>
            <div className="text-xs text-yellow-300">Medium Priority</div>
          </div>
          <div className="text-center p-3 bg-green-500/20 rounded-lg">
            <div className="text-2xl font-bold text-green-400">{data.detailedAnalysis.summary.low}</div>
            <div className="text-xs text-green-300">Low Priority</div>
          </div>
          <div className="text-center p-3 bg-blue-500/20 rounded-lg">
            <div className="text-2xl font-bold text-blue-400">{data.detailedAnalysis.summary.info}</div>
            <div className="text-xs text-blue-300">Informational</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DetailedAnalysis;