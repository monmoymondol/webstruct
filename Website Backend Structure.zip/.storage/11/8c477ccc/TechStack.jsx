import React from 'react';
import { Code2, Database, Server, Palette, Shield, Zap } from 'lucide-react';

const TechStack = ({ data }) => {
  const getTechIcon = (category) => {
    switch (category) {
      case 'Frontend': return Code2;
      case 'Backend': return Server;
      case 'Database': return Database;
      case 'Styling': return Palette;
      case 'Security': return Shield;
      default: return Zap;
    }
  };

  const getTechColor = (category) => {
    switch (category) {
      case 'Frontend': return 'text-blue-400 bg-blue-500/20';
      case 'Backend': return 'text-green-400 bg-green-500/20';
      case 'Database': return 'text-purple-400 bg-purple-500/20';
      case 'Styling': return 'text-pink-400 bg-pink-500/20';
      case 'Security': return 'text-red-400 bg-red-500/20';
      default: return 'text-gray-400 bg-gray-500/20';
    }
  };

  return (
    <div className="bg-black/30 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20">
      <h3 className="text-xl font-bold text-white mb-6 flex items-center">
        <Code2 className="h-5 w-5 mr-2 text-purple-400" />
        Technology Stack
      </h3>
      
      <div className="space-y-6">
        {Object.entries(data.techStack).map(([category, technologies]) => {
          const Icon = getTechIcon(category);
          const colorClass = getTechColor(category);
          
          return (
            <div key={category} className="space-y-3">
              <div className="flex items-center space-x-2">
                <div className={`w-8 h-8 ${colorClass} rounded-lg flex items-center justify-center`}>
                  <Icon className="h-4 w-4" />
                </div>
                <h4 className="text-lg font-semibold text-white">{category}</h4>
              </div>
              
              <div className="grid grid-cols-1 gap-2 ml-10">
                {technologies.map((tech, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-white/5 rounded-lg hover:bg-white/10 transition-colors duration-200">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-cyan-400 rounded-full"></div>
                      <span className="text-white text-sm font-medium">{tech.name}</span>
                    </div>
                    <span className="text-xs text-purple-300 bg-purple-500/20 px-2 py-1 rounded">
                      v{tech.version}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
      
      <div className="mt-6 pt-6 border-t border-purple-500/20">
        <h4 className="text-lg font-semibold text-white mb-4">Performance Metrics</h4>
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 bg-green-500/20 rounded-lg">
            <div className="text-2xl font-bold text-green-400">{data.performance.loadTime}ms</div>
            <div className="text-xs text-green-300">Load Time</div>
          </div>
          <div className="text-center p-3 bg-blue-500/20 rounded-lg">
            <div className="text-2xl font-bold text-blue-400">{data.performance.score}/100</div>
            <div className="text-xs text-blue-300">Performance</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TechStack;