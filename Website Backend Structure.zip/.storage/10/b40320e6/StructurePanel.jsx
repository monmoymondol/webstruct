import React from 'react';
import { Layers, Link, FileText, Image, Code } from 'lucide-react';

const StructurePanel = ({ data }) => {
  const structureItems = [
    {
      icon: Layers,
      label: 'Pages',
      count: data.structure.pages,
      color: 'text-blue-400',
      bgColor: 'bg-blue-500/20'
    },
    {
      icon: Link,
      label: 'External Links',
      count: data.structure.externalLinks,
      color: 'text-green-400',
      bgColor: 'bg-green-500/20'
    },
    {
      icon: Image,
      label: 'Media Files',
      count: data.structure.mediaFiles,
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/20'
    },
    {
      icon: Code,
      label: 'Scripts',
      count: data.structure.scripts,
      color: 'text-orange-400',
      bgColor: 'bg-orange-500/20'
    }
  ];

  return (
    <div className="bg-black/30 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20">
      <h3 className="text-xl font-bold text-white mb-6 flex items-center">
        <FileText className="h-5 w-5 mr-2 text-purple-400" />
        Site Structure
      </h3>
      
      <div className="space-y-4">
        {structureItems.map((item, index) => {
          const Icon = item.icon;
          return (
            <div key={index} className="flex items-center justify-between p-4 bg-white/5 rounded-xl hover:bg-white/10 transition-colors duration-200">
              <div className="flex items-center space-x-3">
                <div className={`w-10 h-10 ${item.bgColor} rounded-lg flex items-center justify-center`}>
                  <Icon className={`h-5 w-5 ${item.color}`} />
                </div>
                <span className="text-white font-medium">{item.label}</span>
              </div>
              <span className={`text-2xl font-bold ${item.color}`}>{item.count}</span>
            </div>
          );
        })}
      </div>
      
      <div className="mt-6 pt-6 border-t border-purple-500/20">
        <h4 className="text-lg font-semibold text-white mb-4">Domain Information</h4>
        <div className="space-y-3">
          <div className="flex justify-between">
            <span className="text-purple-300">Domain:</span>
            <span className="text-white font-mono text-sm">{data.domain}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-purple-300">Subdomains:</span>
            <span className="text-cyan-400 font-bold">{data.subdomains.length}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-purple-300">SSL Status:</span>
            <span className="text-green-400 font-semibold">✓ Secure</span>
          </div>
        </div>
        
        <div className="mt-4">
          <h5 className="text-sm font-semibold text-purple-300 mb-2">Detected Subdomains:</h5>
          <div className="space-y-1">
            {data.subdomains.slice(0, 5).map((subdomain, index) => (
              <div key={index} className="text-xs text-gray-300 font-mono bg-slate-800/50 px-2 py-1 rounded">
                {subdomain}
              </div>
            ))}
            {data.subdomains.length > 5 && (
              <div className="text-xs text-purple-400">+{data.subdomains.length - 5} more</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StructurePanel;