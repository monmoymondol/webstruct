import { Globe, Server, Database, Shield, Cloud, Code, Layers, Network } from 'lucide-react';

export const analyzeWebsite = (url) => {
  // Extract domain from URL
  const domain = new URL(url).hostname;
  
  // Generate realistic mock data based on the domain
  const generateMockData = (domain) => {
    const isPopularSite = ['github.com', 'stackoverflow.com', 'netflix.com', 'amazon.com'].includes(domain);
    
    return {
      domain,
      url,
      timestamp: new Date().toISOString(),
      
      // Network nodes for visualization
      nodes: [
        { id: 'main', type: 'main', label: domain, x: 200, y: 150, icon: Globe, gradient: 'from-purple-500 to-pink-500' },
        { id: 'api', type: 'api', label: `api.${domain}`, x: 350, y: 100, icon: Server, gradient: 'from-blue-500 to-cyan-500' },
        { id: 'cdn', type: 'cdn', label: `cdn.${domain}`, x: 350, y: 200, icon: Cloud, gradient: 'from-orange-500 to-yellow-500' },
        { id: 'db', type: 'database', label: 'Database', x: 500, y: 150, icon: Database, gradient: 'from-green-500 to-emerald-500' },
        { id: 'auth', type: 'security', label: 'Auth Service', x: 200, y: 50, icon: Shield, gradient: 'from-red-500 to-rose-500' },
        { id: 'cache', type: 'api', label: 'Cache Layer', x: 200, y: 250, icon: Server, gradient: 'from-gray-500 to-slate-500' },
      ],
      
      // Connections between nodes
      connections: [
        { from: { x: 200, y: 150 }, to: { x: 350, y: 100 } },
        { from: { x: 200, y: 150 }, to: { x: 350, y: 200 } },
        { from: { x: 350, y: 100 }, to: { x: 500, y: 150 } },
        { from: { x: 200, y: 150 }, to: { x: 200, y: 50 } },
        { from: { x: 200, y: 150 }, to: { x: 200, y: 250 } },
      ],

      // Enhanced network topology
      networkTopology: {
        nodes: [
          { 
            id: 'main', 
            type: 'main', 
            label: domain, 
            x: 200, 
            y: 150, 
            icon: Globe, 
            gradient: 'from-purple-500 to-pink-500',
            traffic: 85,
            secure: true,
            status: 'active',
            responseTime: 120
          },
          { 
            id: 'api', 
            type: 'api', 
            label: `api.${domain}`, 
            x: 350, 
            y: 100, 
            icon: Server, 
            gradient: 'from-blue-500 to-cyan-500',
            traffic: 92,
            secure: true,
            status: 'active',
            responseTime: 45
          },
          { 
            id: 'cdn', 
            type: 'cdn', 
            label: `cdn.${domain}`, 
            x: 350, 
            y: 200, 
            icon: Cloud, 
            gradient: 'from-orange-500 to-yellow-500',
            traffic: 67,
            secure: true,
            status: 'active',
            responseTime: 15
          },
          { 
            id: 'db', 
            type: 'database', 
            label: 'Database', 
            x: 500, 
            y: 150, 
            icon: Database, 
            gradient: 'from-green-500 to-emerald-500',
            traffic: 34,
            secure: true,
            status: 'active',
            responseTime: 8
          },
          { 
            id: 'auth', 
            type: 'security', 
            label: 'Auth Service', 
            x: 200, 
            y: 50, 
            icon: Shield, 
            gradient: 'from-red-500 to-rose-500',
            traffic: 78,
            secure: true,
            status: 'active',
            responseTime: 25
          },
        ],
        connections: [
          { from: { x: 200, y: 150 }, to: { x: 350, y: 100 }, traffic: 85, encrypted: true },
          { from: { x: 200, y: 150 }, to: { x: 350, y: 200 }, traffic: 67, encrypted: true },
          { from: { x: 350, y: 100 }, to: { x: 500, y: 150 }, traffic: 34, encrypted: true },
          { from: { x: 200, y: 150 }, to: { x: 200, y: 50 }, traffic: 78, encrypted: true },
        ],
        stats: {
          throughput: '2.4 GB/s',
          latency: 45,
          connections: 1247,
          peakConnections: 2891,
          healthScore: 94
        }
      },
      
      // Site structure information
      structure: {
        pages: isPopularSite ? Math.floor(Math.random() * 1000) + 500 : Math.floor(Math.random() * 100) + 20,
        externalLinks: isPopularSite ? Math.floor(Math.random() * 500) + 200 : Math.floor(Math.random() * 50) + 10,
        mediaFiles: isPopularSite ? Math.floor(Math.random() * 2000) + 1000 : Math.floor(Math.random() * 200) + 50,
        scripts: isPopularSite ? Math.floor(Math.random() * 100) + 50 : Math.floor(Math.random() * 30) + 10,
      },
      
      // Detected subdomains
      subdomains: generateSubdomains(domain, isPopularSite),
      
      // Technology stack
      techStack: generateTechStack(domain, isPopularSite),
      
      // Performance metrics
      performance: {
        loadTime: isPopularSite ? Math.floor(Math.random() * 500) + 200 : Math.floor(Math.random() * 1000) + 500,
        score: isPopularSite ? Math.floor(Math.random() * 20) + 80 : Math.floor(Math.random() * 40) + 60,
      },
      
      // Request types for charts
      requestTypes: [
        { name: 'HTML', count: Math.floor(Math.random() * 50) + 20 },
        { name: 'CSS', count: Math.floor(Math.random() * 30) + 10 },
        { name: 'JS', count: Math.floor(Math.random() * 40) + 15 },
        { name: 'Images', count: Math.floor(Math.random() * 100) + 50 },
        { name: 'API', count: Math.floor(Math.random() * 60) + 30 },
      ],
      
      // Connection types for pie chart
      connectionTypes: [
        { name: 'HTTPS', value: 70 },
        { name: 'WebSocket', value: 15 },
        { name: 'API Calls', value: 10 },
        { name: 'CDN', value: 5 },
      ],
      
      // Backend services
      backendServices: generateBackendServices(domain, isPopularSite),

      // Detailed analysis data
      detailedAnalysis: generateDetailedAnalysis(domain, isPopularSite),
    };
  };
  
  return generateMockData(domain);
};

const generateSubdomains = (domain, isPopular) => {
  const commonSubdomains = ['www', 'api', 'cdn', 'static', 'assets', 'admin', 'auth', 'mail'];
  const popularSubdomains = ['blog', 'docs', 'support', 'status', 'dev', 'staging', 'mobile', 'app'];
  
  const subdomains = commonSubdomains.map(sub => `${sub}.${domain}`);
  
  if (isPopular) {
    subdomains.push(...popularSubdomains.map(sub => `${sub}.${domain}`));
  }
  
  return subdomains.slice(0, Math.floor(Math.random() * 8) + 4);
};

const generateTechStack = (domain, isPopular) => {
  const techStacks = {
    'github.com': {
      Frontend: [
        { name: 'React', version: '18.2.0' },
        { name: 'TypeScript', version: '4.9.5' },
        { name: 'Webpack', version: '5.75.0' },
      ],
      Backend: [
        { name: 'Ruby on Rails', version: '7.0.4' },
        { name: 'Node.js', version: '18.12.1' },
        { name: 'Go', version: '1.19.4' },
      ],
      Database: [
        { name: 'PostgreSQL', version: '14.6' },
        { name: 'Redis', version: '7.0.5' },
        { name: 'Elasticsearch', version: '8.5.3' },
      ],
      Styling: [
        { name: 'Primer CSS', version: '21.0.7' },
        { name: 'SCSS', version: '1.56.1' },
      ],
      Security: [
        { name: 'OAuth 2.0', version: '2.1' },
        { name: 'JWT', version: '9.0.0' },
      ],
    },
    'stackoverflow.com': {
      Frontend: [
        { name: 'jQuery', version: '3.6.0' },
        { name: 'TypeScript', version: '4.8.4' },
        { name: 'Stencil', version: '2.18.1' },
      ],
      Backend: [
        { name: 'ASP.NET Core', version: '6.0' },
        { name: 'C#', version: '10.0' },
      ],
      Database: [
        { name: 'SQL Server', version: '2019' },
        { name: 'Redis', version: '6.2.7' },
      ],
      Styling: [
        { name: 'LESS', version: '4.1.3' },
        { name: 'Bootstrap', version: '5.2.2' },
      ],
      Security: [
        { name: 'OpenID Connect', version: '1.0' },
        { name: 'ASP.NET Identity', version: '6.0' },
      ],
    },
    default: {
      Frontend: [
        { name: 'React', version: '18.2.0' },
        { name: 'JavaScript', version: 'ES2022' },
      ],
      Backend: [
        { name: 'Node.js', version: '18.12.1' },
        { name: 'Express', version: '4.18.2' },
      ],
      Database: [
        { name: 'MongoDB', version: '6.0.3' },
        { name: 'Redis', version: '7.0.5' },
      ],
      Styling: [
        { name: 'CSS3', version: '3.0' },
        { name: 'Tailwind CSS', version: '3.2.4' },
      ],
      Security: [
        { name: 'JWT', version: '9.0.0' },
        { name: 'bcrypt', version: '5.1.0' },
      ],
    },
  };
  
  return techStacks[domain] || techStacks.default;
};

const generateBackendServices = (domain, isPopular) => {
  const baseServices = [
    {
      name: 'Main API',
      type: 'API',
      endpoint: `/api/v1`,
      status: 'active',
      responseTime: Math.floor(Math.random() * 100) + 50,
    },
    {
      name: 'Authentication',
      type: 'API',
      endpoint: `/auth`,
      status: 'active',
      responseTime: Math.floor(Math.random() * 50) + 20,
    },
    {
      name: 'CDN',
      type: 'CDN',
      endpoint: `cdn.${domain}`,
      status: 'active',
      responseTime: Math.floor(Math.random() * 30) + 10,
    },
    {
      name: 'Database',
      type: 'Database',
      endpoint: 'Internal',
      status: 'active',
      responseTime: Math.floor(Math.random() * 20) + 5,
    },
  ];
  
  if (isPopular) {
    baseServices.push(
      {
        name: 'Search API',
        type: 'API',
        endpoint: `/search/v2`,
        status: 'active',
        responseTime: Math.floor(Math.random() * 80) + 40,
      },
      {
        name: 'Analytics',
        type: 'API',
        endpoint: `/analytics`,
        status: 'active',
        responseTime: Math.floor(Math.random() * 60) + 30,
      },
      {
        name: 'Cache Layer',
        type: 'Database',
        endpoint: 'Redis Cluster',
        status: 'active',
        responseTime: Math.floor(Math.random() * 10) + 2,
      }
    );
  }
  
  return baseServices;
};

const generateDetailedAnalysis = (domain, isPopular) => {
  const baseAnalysis = {
    totalFindings: 0,
    security: [
      {
        title: 'SSL/TLS Configuration',
        severity: 'low',
        description: 'Website uses modern TLS 1.3 encryption with strong cipher suites. Certificate is valid and properly configured.',
        details: [
          'TLS 1.3 protocol enabled',
          'Strong cipher suites (AES-256-GCM)',
          'Perfect Forward Secrecy enabled',
          'HSTS header present with max-age=31536000'
        ],
        recommendation: 'Consider implementing Certificate Transparency monitoring for enhanced security.',
        impact: 'Low - Security posture is strong',
        confidence: 95
      },
      {
        title: 'Content Security Policy',
        severity: isPopular ? 'low' : 'medium',
        description: isPopular ? 'Comprehensive CSP headers detected with proper directives.' : 'Basic CSP implementation found, could be enhanced for better protection.',
        details: isPopular ? [
          'strict-dynamic directive implemented',
          'nonce-based script execution',
          'No unsafe-inline or unsafe-eval',
          'Proper frame-ancestors directive'
        ] : [
          'Basic CSP headers present',
          'Some unsafe-inline usage detected',
          'Missing frame-ancestors directive'
        ],
        recommendation: isPopular ? 'Monitor CSP violation reports regularly.' : 'Implement stricter CSP policies and remove unsafe-inline directives.',
        impact: isPopular ? 'Low - Well protected' : 'Medium - Potential XSS vulnerabilities',
        confidence: 88
      }
    ],
    performance: [
      {
        title: 'Core Web Vitals',
        severity: isPopular ? 'low' : 'medium',
        description: `Website ${isPopular ? 'meets' : 'partially meets'} Google's Core Web Vitals thresholds for user experience.`,
        details: isPopular ? [
          'LCP: 1.2s (Good - under 2.5s)',
          'FID: 45ms (Good - under 100ms)',
          'CLS: 0.08 (Good - under 0.1)',
          'TTFB: 180ms (Good - under 600ms)'
        ] : [
          'LCP: 3.1s (Needs Improvement)',
          'FID: 120ms (Needs Improvement)',
          'CLS: 0.15 (Poor - over 0.25)',
          'TTFB: 890ms (Needs Improvement)'
        ],
        recommendation: isPopular ? 'Continue monitoring and optimizing for mobile devices.' : 'Optimize images, reduce JavaScript bundle size, and implement lazy loading.',
        impact: isPopular ? 'Low - Good user experience' : 'High - Poor user experience affects SEO',
        confidence: 92
      },
      {
        title: 'Resource Optimization',
        severity: 'medium',
        description: 'Several opportunities identified for resource optimization and caching improvements.',
        details: [
          'Uncompressed JavaScript files detected',
          'Missing browser caching headers on static assets',
          'Unused CSS rules found (estimated 23%)',
          'Images not optimized for modern formats (WebP/AVIF)'
        ],
        recommendation: 'Implement Gzip/Brotli compression, set proper cache headers, and use modern image formats.',
        impact: 'Medium - 15-25% performance improvement possible',
        confidence: 85
      }
    ],
    architecture: [
      {
        title: 'Microservices Architecture',
        severity: 'info',
        description: isPopular ? 'Well-structured microservices architecture with proper service separation.' : 'Monolithic architecture detected with some service separation.',
        details: isPopular ? [
          'API Gateway pattern implemented',
          'Service mesh for inter-service communication',
          'Proper service boundaries identified',
          'Load balancing across multiple instances'
        ] : [
          'Single application server detected',
          'Database and application tightly coupled',
          'Limited horizontal scaling capabilities'
        ],
        recommendation: isPopular ? 'Consider implementing distributed tracing for better observability.' : 'Plan migration to microservices for better scalability.',
        impact: isPopular ? 'Low - Architecture is scalable' : 'Medium - Limited scalability',
        confidence: 78
      }
    ],
    apis: [
      {
        title: 'REST API Design',
        severity: 'low',
        description: 'RESTful API endpoints follow standard conventions with proper HTTP methods and status codes.',
        details: [
          'Consistent URL patterns (/api/v1/resource)',
          'Proper HTTP status codes (200, 201, 404, 500)',
          'JSON response format standardized',
          'API versioning implemented'
        ],
        recommendation: 'Consider implementing GraphQL for more flexible data fetching.',
        impact: 'Low - API is well-designed',
        confidence: 90
      },
      {
        title: 'Rate Limiting',
        severity: isPopular ? 'low' : 'high',
        description: isPopular ? 'Comprehensive rate limiting implemented across all API endpoints.' : 'No rate limiting detected on API endpoints.',
        details: isPopular ? [
          'Per-user rate limits: 1000 req/hour',
          'Per-IP rate limits: 100 req/minute',
          'Proper 429 status code responses',
          'Rate limit headers included'
        ] : [
          'No X-RateLimit headers detected',
          'No 429 responses observed',
          'Potential for API abuse'
        ],
        recommendation: isPopular ? 'Monitor rate limit metrics and adjust thresholds as needed.' : 'Implement rate limiting immediately to prevent API abuse.',
        impact: isPopular ? 'Low - Well protected' : 'High - Vulnerable to abuse',
        confidence: 95
      }
    ],
    database: [
      {
        title: 'Database Performance',
        severity: 'medium',
        description: 'Database queries show room for optimization with some slow-running queries identified.',
        details: [
          'Average query time: 45ms',
          '12 queries taking >100ms detected',
          'Missing indexes on frequently queried columns',
          'Connection pool utilization: 78%'
        ],
        recommendation: 'Add indexes on frequently queried columns and optimize slow queries.',
        impact: 'Medium - 20-30% performance improvement possible',
        confidence: 82
      }
    ],
    infrastructure: [
      {
        title: 'CDN Configuration',
        severity: 'low',
        description: 'Content Delivery Network properly configured with global edge locations.',
        details: [
          'Global CDN with 150+ edge locations',
          'Static assets cached for 1 year',
          'Dynamic content cached for 5 minutes',
          'Automatic image optimization enabled'
        ],
        recommendation: 'Consider implementing edge computing for dynamic content.',
        impact: 'Low - CDN is well optimized',
        confidence: 88
      }
    ]
  };

  // Calculate total findings
  baseAnalysis.totalFindings = Object.values(baseAnalysis).reduce((total, category) => {
    if (Array.isArray(category)) {
      return total + category.length;
    }
    return total;
  }, 0) - 1; // Subtract 1 for totalFindings itself

  // Calculate summary
  const allFindings = [
    ...baseAnalysis.security,
    ...baseAnalysis.performance,
    ...baseAnalysis.architecture,
    ...baseAnalysis.apis,
    ...baseAnalysis.database,
    ...baseAnalysis.infrastructure
  ];

  baseAnalysis.summary = {
    high: allFindings.filter(f => f.severity === 'high').length,
    medium: allFindings.filter(f => f.severity === 'medium').length,
    low: allFindings.filter(f => f.severity === 'low').length,
    info: allFindings.filter(f => f.severity === 'info').length
  };

  return baseAnalysis;
};